# Group A-17 Final Project

__Names:__ Nathan Lindley, Anushka Shinde, Kaden Hoversten, Parul Goswami, and Rithwik Raman

__Computing IDs:__ nfl6fh, dgs5qm, keh9eq, pg7wfm, xak7jw
